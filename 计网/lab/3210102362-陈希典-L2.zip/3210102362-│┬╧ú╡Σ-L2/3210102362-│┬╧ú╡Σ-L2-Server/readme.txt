点击launch启动 CtrlC退出服务器
或者使用g++ code/Server.cpp -o s -lws2_32手动编译
要求支持-lws2_32库